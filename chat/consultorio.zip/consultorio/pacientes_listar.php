<?php
include '../../backend/checklogin.php';
include '../../backend/header.php';
include '../../backend/conexion.php';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Pacientes - Consultorio</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .nowrap { white-space: nowrap; }
    .pagination { margin: 0; }
  </style>
</head>
<body>
<main class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Pacientes</h2>
    <div>
      <a href="turnos_form.php" class="btn btn-success">Nuevo Turno</a>
      <!-- botón nuevo: Agregar paciente (abre modal) -->
      <button id="btnAddPacienteTop" class="btn btn-primary ms-2" data-bs-toggle="modal" data-bs-target="#modalNuevoPaciente">Agregar Paciente</button>

      <a href="dashboard.php" class="btn btn-secondary ms-2">Volver</a>
    </div>
  </div>

  <div class="row g-2 mb-3">
    <div class="col-md-4"><input id="qPac" class="form-control" placeholder="Buscar por nombre o email..."></div>
    <div class="col-auto"><select id="sortPac" class="form-select"><option value="nombre_asc">A → Z</option><option value="nombre_desc">Z → A</option></select></div>
    <div class="col-auto"><select id="perPagePac" class="form-select"><option value="10">10</option><option value="20" selected>20</option><option value="50">50</option></select></div>
    <div class="col-auto"><button id="clearPac" class="btn btn-outline-secondary">Limpiar</button></div>
  </div>

  <div id="resultadoPac" class="table-responsive"></div>
</main>

<!-- Modal para agregar/editar paciente (mismos ids/campos que usamos en turnos_form.php) -->
<div class="modal fade" id="modalNuevoPaciente" tabindex="-1" aria-labelledby="modalNuevoPacienteLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formNuevoPaciente">
        <div class="modal-header">
          <h5 class="modal-title" id="modalNuevoPacienteLabel">Agregar paciente</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <div id="nuevoPacienteAlert" class="alert d-none" role="alert"></div>

          <!-- hidden id_usuario when editing -->
          <input type="hidden" id="form_id_usuario" name="id_usuario" value="">

          <div class="mb-3">
            <label for="pacienteNombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="pacienteNombre" name="nombre" required>
          </div>
          <div class="mb-3">
            <label for="pacienteApellido" class="form-label">Apellido</label>
            <input type="text" class="form-control" id="pacienteApellido" name="apellido" required>
          </div>
          <div class="mb-3">
            <label for="pacienteEmail" class="form-label">Email</label>
            <input type="email" class="form-control" id="pacienteEmail" name="email" placeholder="ejemplo@dominio.com">
            <div class="form-text">Opcional pero recomendado. Debe ser único si existe.</div>
          </div>

          <!-- Campos ocultos: id_rol y id_negocio -->
          <input type="hidden" name="id_rol" value="6">
          <input type="hidden" name="id_negocio" value="1">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary" id="btnGuardarPacienteModal">Guardar paciente</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal eliminar -->
<div class="modal fade" id="modalBorrarPaciente" tabindex="-1" aria-labelledby="modalBorrarPacienteLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <form id="formBorrarPaciente">
        <div class="modal-header">
          <h5 class="modal-title" id="modalBorrarPacienteLabel">Confirmar borrado</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <div id="borrarPacienteAlert" class="alert d-none" role="alert"></div>
          <p id="borrarPacienteMsg">¿Borrar paciente?</p>
          <input type="hidden" id="borrar_id_usuario" name="id_usuario" value="">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger" id="btnBorrarPaciente">Borrar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal para ver Turnos del paciente -->
<div class="modal fade" id="modalTurnosPac" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Turnos</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" id="modalTurnosBody">Cargando...</div>
      <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button></div>
    </div>
  </div>
</div>

<!-- Modal para ver Historias del paciente -->
<div class="modal fade" id="modalHistPac" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Historias Clínicas</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" id="modalHistBody">Cargando...</div>
      <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button></div>
    </div>
  </div>
</div>

<footer class="text-center py-3">© <?= date('Y') ?> Grupo Lux — Consultorio</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
/* Utilidades */
function debounce(fn, delay){ let t; return function(...a){ clearTimeout(t); t = setTimeout(()=> fn.apply(this,a), delay); }; }
function escapeHtml(s){ if(!s) return ''; return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m]); }
function showAlert(el, type, msg){ el.classList.remove('d-none','alert-success','alert-danger','alert-info'); el.classList.add('alert-'+type); el.innerText = msg; }

/* BroadcastChannel (notificaciones entre pestañas) */
const bcSupported = typeof BroadcastChannel !== 'undefined';
const channelName = 'lux_pacientes';
if (bcSupported) {
  const bc = new BroadcastChannel(channelName);
  bc.onmessage = (ev) => {
    // Cuando otra pestaña crea/actualiza/borra un paciente, refrescamos la tabla
    try { fetchPac(1); } catch(e){ console.error(e); }
  };
} else {
  window.addEventListener('storage', function(e){
    if (e.key === channelName && e.newValue) {
      try { fetchPac(1); } catch(err){ console.error(err); }
      localStorage.removeItem(channelName);
    }
  });
}

/* Elementos */
const el = {
  q: document.getElementById('qPac'),
  sort: document.getElementById('sortPac'),
  per: document.getElementById('perPagePac'),
  resultado: document.getElementById('resultadoPac'),
  clear: document.getElementById('clearPac'),
  btnAddTop: document.getElementById('btnAddPacienteTop')
};

/* Construir body POST */
function buildBody(page=1){
  const body = new URLSearchParams();
  if (el.q.value.trim()) body.set('q', el.q.value.trim());
  if (el.sort.value) body.set('sort', el.sort.value);
  body.set('per_page', el.per.value || '20');
  body.set('page', page);
  return body.toString();
}

/* Fetch y render de pacientes (usa pacientes_api.php) */
async function fetchPac(page=1){
  el.resultado.innerHTML = '<div class="p-4 text-center">Cargando...</div>';
  try {
    const res = await fetch('pacientes_api.php', {
      method:'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      credentials:'same-origin',
      body: buildBody(page)
    });
    const text = await res.text();
    let js;
    try { js = JSON.parse(text); } catch(e){ el.resultado.innerHTML = '<div class="alert alert-danger">Respuesta inválida del servidor. Mirá DevTools.</div>'; console.error('pacientes_api raw:', text); return; }
    if (!js.success) { el.resultado.innerHTML = '<div class="alert alert-danger">Error: ' + (js.error||'Error servidor') + '</div>'; return; }
    renderTable(js);
  } catch(err) {
    el.resultado.innerHTML = '<div class="alert alert-danger">Error: ' + err.message + '</div>';
  }
}

/* Render tabla con botones editar/borrar (y meta-data en atributos) */
function renderTable(payload){
  const rows = payload.data || [];
  const total = payload.total || 0;
  const page = payload.page || 1;
  const total_pages = payload.total_pages || 1;

  let html = '<table class="table table-striped"><thead><tr><th>ID</th><th>Nombre</th><th>Email</th><th>Turnos</th><th>Historias</th><th>Acciones</th></tr></thead><tbody>';
  if (rows.length === 0) html += '<tr><td colspan="6" class="text-center">No se encontraron pacientes.</td></tr>';
  else {
    for (const r of rows) {
      const id = r.id_usuario;
      const nombre = escapeHtml((r.nombre||'') + ' ' + (r.apellido||''));
      const email = escapeHtml(r.email || '');
      // Guardamos data-* en el botón editar para prefilling
      html += `<tr>
        <td class="nowrap">${id}</td>
        <td>${nombre}</td>
        <td>${email}</td>
        <td class="nowrap">${r.turnos_count}</td>
        <td class="nowrap">${r.historias_count}</td>
        <td class="nowrap">
          <button class="btn btn-sm btn-outline-secondary js-edit-pac"
            data-id="${id}"
            data-nombre="${escapeHtml(r.nombre||'')}"
            data-apellido="${escapeHtml(r.apellido||'')}"
            data-email="${escapeHtml(r.email||'')}">Editar</button>

          <button class="btn btn-sm btn-danger js-del-pac"
            data-id="${id}"
            data-nombre="${escapeHtml((r.nombre||'') + ' ' + (r.apellido||''))}">Borrar</button>

          <button class="btn btn-sm btn-info js-ver-turnos" data-id="${id}">Turnos</button>
          <button class="btn btn-sm btn-primary js-ver-hist" data-id="${id}">Historias</button>
        </td>
      </tr>`;
    }
  }
  html += '</tbody></table>';

  // pagination simple
  html += '<div class="d-flex justify-content-between align-items-center"><div>Mostrando ' + rows.length + ' de ' + total + ' resultados</div>';
  html += '<nav><ul class="pagination mb-0">';
  if (page > 1) html += `<li class="page-item"><a class="page-link" href="#" data-page="${page-1}">«</a></li>`; else html += `<li class="page-item disabled"><span class="page-link">«</span></li>`;
  const start = Math.max(1, page-2); const end = Math.min(total_pages, page+2);
  for (let p=start;p<=end;p++) html += `<li class="page-item${p===page?' active':''}"><a class="page-link" href="#" data-page="${p}">${p}</a></li>`;
  if (page < total_pages) html += `<li class="page-item"><a class="page-link" href="#" data-page="${page+1}">»</a></li>`; else html += `<li class="page-item disabled"><span class="page-link">»</span></li>`;
  html += '</ul></nav></div>';

  el.resultado.innerHTML = html;

  // pagination handlers
  document.querySelectorAll('#resultadoPac .page-link[data-page]').forEach(a=>{
    a.addEventListener('click', (ev)=>{ ev.preventDefault(); fetchPac(parseInt(a.dataset.page)||1); });
  });

  // attach buttons: editar / borrar / ver turnos / ver historias
  document.querySelectorAll('.js-edit-pac').forEach(b=>{
    b.addEventListener('click', (ev)=> {
      const id = b.dataset.id;
      const nombre = b.dataset.nombre || '';
      const apellido = b.dataset.apellido || '';
      const email = b.dataset.email || '';
      openEditModal({ id, nombre, apellido, email });
    });
  });
  document.querySelectorAll('.js-del-pac').forEach(b=>{
    b.addEventListener('click', ()=> openDeleteModal({ id: b.dataset.id, nombre: b.dataset.nombre }) );
  });
  document.querySelectorAll('.js-ver-turnos').forEach(b=>{
    b.addEventListener('click', ()=> openTurnosModal(b.dataset.id));
  });
  document.querySelectorAll('.js-ver-hist').forEach(b=>{
    b.addEventListener('click', ()=> openHistModal(b.dataset.id));
  });
}

/* Abrir modal Turnos por paciente */
async function openTurnosModal(id){
  const body = new URLSearchParams(); body.set('paciente', id); body.set('per_page', '100');
  const modalBody = document.getElementById('modalTurnosBody');
  modalBody.innerHTML = 'Cargando...';
  const modal = new bootstrap.Modal(document.getElementById('modalTurnosPac'));
  modal.show();

  try {
    const res = await fetch('turnos_por_paciente.php', {
      method:'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, credentials:'same-origin', body: body.toString()
    });
    const text = await res.text(); const js = JSON.parse(text);
    if (!js.success) { modalBody.innerHTML = '<div class="alert alert-danger">'+(js.error||'Error')+'</div>'; return; }
    if (!js.data.length) { modalBody.innerHTML = '<div class="p-3">No tiene turnos registrados.</div>'; return; }
    let html = '<ul class="list-group">';
    for (const t of js.data) {
      html += `<li class="list-group-item"><strong>${t.fecha} ${t.hora || ''}</strong> — ${escapeHtml(t.medico_nombre || '')} — Estado: ${escapeHtml(t.estado || '')}</li>`;
    }
    html += '</ul>';
    modalBody.innerHTML = html;
  } catch(err) {
    modalBody.innerHTML = '<div class="alert alert-danger">Error: '+err.message+'</div>';
  }
}

/* Abrir modal Historia por paciente */
async function openHistModal(id){
  const body = new URLSearchParams(); body.set('paciente', id); body.set('per_page', '100');
  const modalBody = document.getElementById('modalHistBody');
  modalBody.innerHTML = 'Cargando...';
  const modal = new bootstrap.Modal(document.getElementById('modalHistPac'));
  modal.show();

  try {
    const res = await fetch('historia_por_paciente.php', {
      method:'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, credentials:'same-origin', body: body.toString()
    });
    const text = await res.text(); const js = JSON.parse(text);
    if (!js.success) { modalBody.innerHTML = '<div class="alert alert-danger">'+(js.error||'Error')+'</div>'; return; }
    if (!js.data.length) { modalBody.innerHTML = '<div class="p-3">No hay historias registradas.</div>'; return; }
    let html = '<div class="accordion" id="accHist">';
    js.data.forEach((h,i)=>{
      const idh = 'hist' + h.id_historia;
      html += `<div class="accordion-item">
        <h2 class="accordion-header" id="h${idh}">
          <button class="accordion-button ${i? 'collapsed':''}" type="button" data-bs-toggle="collapse" data-bs-target="#${idh}">${h.fecha} — ${escapeHtml(h.paciente_nombre)}</button>
        </h2>
        <div id="${idh}" class="accordion-collapse collapse ${i? '':'show'}" data-bs-parent="#accHist">
          <div class="accordion-body">${escapeHtml(h.descripcion).replace(/\n/g,'<br>')}</div>
        </div>
      </div>`;
    });
    html += '</div>';
    modalBody.innerHTML = html;
  } catch(err) {
    modalBody.innerHTML = '<div class="alert alert-danger">Error: '+err.message+'</div>';
  }
}

/* ---------- Helpers modal (reuse) ---------- */
// Close modal robustly and clean backdrop (same logic we used antes)
function closeModalAndCleanupById(modalId){
  try {
    const modalEl = document.getElementById(modalId);
    const inst = bootstrap.Modal.getInstance(modalEl);
    if (inst) inst.hide(); else { try { (new bootstrap.Modal(modalEl)).hide(); } catch(e){} }
  } catch(e){ console.warn('closeModal error', e); }
  document.querySelectorAll('.modal-backdrop').forEach(n => n.remove());
  document.body.classList.remove('modal-open');
}

/* ---------- Open Edit Modal (prefill) ---------- */
function openEditModal({id, nombre='', apellido='', email=''}) {
  // set modal title to "Editar" when id present
  const title = document.getElementById('modalNuevoPacienteLabel');
  title.innerText = id ? 'Editar paciente' : 'Agregar paciente';
  document.getElementById('form_id_usuario').value = id || '';
  document.getElementById('pacienteNombre').value = nombre || '';
  document.getElementById('pacienteApellido').value = apellido || '';
  document.getElementById('pacienteEmail').value = email || '';
  // show modal
  const modal = new bootstrap.Modal(document.getElementById('modalNuevoPaciente'));
  modal.show();
}

/* ---------- Open Delete Modal ---------- */
function openDeleteModal({id, nombre}) {
  document.getElementById('borrar_id_usuario').value = id;
  document.getElementById('borrarPacienteMsg').innerText = `¿Borrar al paciente "${nombre}" (ID ${id})? Esta acción es irreversible.`;
  document.getElementById('borrarPacienteAlert').classList.add('d-none');
  const modal = new bootstrap.Modal(document.getElementById('modalBorrarPaciente'));
  modal.show();
}

/* ---------- Submit del modal para crear/editar paciente (robusto y con broadcasting) ---------- */
document.getElementById('formNuevoPaciente').addEventListener('submit', function(e){
  e.preventDefault();
  const form = e.target;
  const btn = document.getElementById('btnGuardarPacienteModal');
  const alertEl = document.getElementById('nuevoPacienteAlert');
  alertEl.classList.add('d-none');
  btn.disabled = true;

  const formData = new FormData(form);

  // use same endpoint paciente_guardar_ajax.php for create/update (backend must support id_usuario to update)
  fetch('paciente_guardar_ajax.php', {
    method: 'POST',
    body: formData,
    credentials: 'same-origin'
  })
  .then(async r => {
    const text = await r.text();
    try { return JSON.parse(text); } catch (errParse) {
      throw new Error('Respuesta inválida del servidor. Revisá DevTools → Network. Respuesta: ' + text.slice(0,500));
    }
  })
  .then(js => {
    btn.disabled = false;
    if (js.success) {
      // broadcast a otras pestañas para que hagan fetchPac(1)
      try {
        const pacObj = { id: js.id, nombre_completo: js.nombre_completo, email: js.email || '' };
        if (bcSupported) {
          const bc2 = new BroadcastChannel(channelName);
          bc2.postMessage(pacObj);
          bc2.close();
        } else {
          localStorage.setItem(channelName, JSON.stringify(pacObj));
          setTimeout(()=> localStorage.removeItem(channelName), 600);
        }
      } catch(bcErr){ console.warn('No se pudo broadcast:', bcErr); }

      // si devuelve warning, mostrarlo brevemente
      if (js.warning) {
        showAlert(alertEl, 'info', js.warning);
        setTimeout(()=> {
          closeModalAndCleanupById('modalNuevoPaciente');
          form.reset();
          fetchPac(1);
        }, 1400);
      } else {
        closeModalAndCleanupById('modalNuevoPaciente');
        form.reset();
        fetchPac(1);
      }
    } else {
      // mostrar error detallado dentro del modal (ej. "email ya registrado" o "ya existe nombre... agregá email")
      showAlert(alertEl, 'danger', js.error || 'Error al procesar');
    }
  })
  .catch(err => {
    btn.disabled = false;
    showAlert(alertEl, 'danger', err.message || 'Error de red');
    console.error('Error en paciente_guardar_ajax:', err);
    // limpieza forzada si quedó backdrop pegado
    setTimeout(() => {
      const anyBackdrop = document.querySelector('.modal-backdrop');
      const modalEl = document.getElementById('modalNuevoPaciente');
      const isHidden = modalEl && window.getComputedStyle(modalEl).display === 'none';
      if (anyBackdrop && isHidden) {
        document.querySelectorAll('.modal-backdrop').forEach(n => n.remove());
        document.body.classList.remove('modal-open');
      }
    }, 300);
  });
});

/* ---------- Submit del modal para BORRAR paciente (AJAX) ---------- */
document.getElementById('formBorrarPaciente').addEventListener('submit', function(e){
  e.preventDefault();
  const btn = document.getElementById('btnBorrarPaciente');
  const alertEl = document.getElementById('borrarPacienteAlert');
  alertEl.classList.add('d-none');
  btn.disabled = true;
  const id_usuario = document.getElementById('borrar_id_usuario').value;

  fetch('paciente_borrar_ajax.php', {
    method: 'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    credentials:'same-origin',
    body: new URLSearchParams({ id_usuario })
  })
  .then(async r => {
    const text = await r.text();
    try { return JSON.parse(text); } catch(e){ throw new Error('Respuesta inválida del servidor: ' + text.slice(0,300)); }
  })
  .then(js => {
    btn.disabled = false;
    if (js.success) {
      // broadcast para otras tabs
      try {
        const pacObj = { action: 'delete', id: parseInt(id_usuario) };
        if (bcSupported) {
          const bc2 = new BroadcastChannel(channelName);
          bc2.postMessage(pacObj);
          bc2.close();
        } else {
          localStorage.setItem(channelName, JSON.stringify(pacObj));
          setTimeout(()=> localStorage.removeItem(channelName), 600);
        }
      } catch(e){ console.warn(e); }

      closeModalAndCleanupById('modalBorrarPaciente');
      fetchPac(1);
    } else {
      showAlert(alertEl, 'danger', js.error || 'Error al borrar');
    }
  })
  .catch(err => {
    btn.disabled = false;
    showAlert(alertEl, 'danger', err.message || 'Error de red');
    console.error('Error borrando paciente:', err);
    setTimeout(()=> {
      const anyBackdrop = document.querySelector('.modal-backdrop');
      const modalEl = document.getElementById('modalBorrarPaciente');
      const isHidden = modalEl && window.getComputedStyle(modalEl).display === 'none';
      if (anyBackdrop && isHidden) {
        document.querySelectorAll('.modal-backdrop').forEach(n => n.remove());
        document.body.classList.remove('modal-open');
      }
    }, 300);
  });
});

/* ---------- Binds y carga inicial ---------- */
const deb = debounce(()=> fetchPac(1), 300);
el.q.addEventListener('input', deb);
el.sort.addEventListener('change', ()=> fetchPac(1));
el.per.addEventListener('change', ()=> fetchPac(1));
el.clear.addEventListener('click', ()=> { el.q.value=''; el.sort.value='nombre_asc'; el.per.value='20'; fetchPac(1); });

// Si el botón superior abre modal, limpiamos el modal antes de mostrar
if (el.btnAddTop) {
  el.btnAddTop.addEventListener('click', ()=> {
    const alertEl = document.getElementById('nuevoPacienteAlert');
    alertEl.classList.add('d-none');
    const title = document.getElementById('modalNuevoPacienteLabel');
    title.innerText = 'Agregar paciente';
    document.getElementById('formNuevoPaciente').reset();
    document.getElementById('form_id_usuario').value = '';
  });
}

// carga inicial
fetchPac(1);
</script>
</body>
</html>


