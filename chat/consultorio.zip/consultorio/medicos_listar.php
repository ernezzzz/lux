<?php
include '../../backend/checklogin.php';
include '../../backend/header.php';
include '../../backend/conexion.php';

// cargar especialidades existentes (distintas)
$sp_res = mysqli_query($conn, "SELECT DISTINCT especialidad FROM medicos WHERE COALESCE(especialidad,'') <> '' ORDER BY especialidad");
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Médicos - Consultorio (AJAX)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>.pagination{margin:0} td.nowrap{white-space:nowrap}</style>
</head>
<body>
<main class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Médicos</h2>
    <div>
      <a href="medicos_form.php" class="btn btn-success" id="linkNuevoMedico">Nuevo Médico</a>
      <a href="dashboard.php" class="btn btn-secondary">Volver</a>
    </div>
  </div>

  <div class="row g-2 mb-3">
    <div class="col-md-4"><input id="qMed" class="form-control" placeholder="Buscar por nombre o apellido..."></div>
    <div class="col-auto"><select id="filter_esp" class="form-select"><option value="">Todas las especialidades</option><?php while($s = mysqli_fetch_assoc($sp_res)){ echo '<option value="'.htmlspecialchars($s['especialidad']).'">'.htmlspecialchars($s['especialidad']).'</option>'; } ?></select></div>
    <div class="col-auto"><select id="sortMed" class="form-select"><option value="nombre_asc">A → Z</option><option value="nombre_desc">Z → A</option></select></div>
    <div class="col-auto"><select id="perPageMed" class="form-select"><option value="10">10</option><option value="20" selected>20</option><option value="50">50</option></select></div>
    <div class="col-auto"><button id="clearMed" class="btn btn-outline-secondary">Limpiar</button></div>
  </div>

  <div id="resultadoMed" class="table-responsive"></div>
</main>

<footer class="text-center py-3">© <?= date('Y') ?> Grupo Lux — Consultorio</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function debounce(fn, delay){ let t; return function(...a){ clearTimeout(t); t = setTimeout(()=> fn.apply(this,a), delay); }; }
function escapeHtml(s){ if(!s) return ''; return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m]); }

const elMed = {
  q: document.getElementById('qMed'),
  esp: document.getElementById('filter_esp'),
  sort: document.getElementById('sortMed'),
  per: document.getElementById('perPageMed'),
  resultado: document.getElementById('resultadoMed'),
  clear: document.getElementById('clearMed'),
  linkNuevo: document.getElementById('linkNuevoMedico')
};

function buildMedBody(page=1){
  const body = new URLSearchParams();
  if (elMed.q.value.trim()) body.set('q', elMed.q.value.trim());
  if (elMed.esp.value) body.set('especialidad', elMed.esp.value);
  if (elMed.sort.value) body.set('sort', elMed.sort.value);
  body.set('per_page', elMed.per.value || '20');
  body.set('page', page);
  return body.toString();
}

async function fetchMed(page=1){
  elMed.resultado.innerHTML = '<div class="p-4 text-center">Cargando...</div>';
  try{
    const res = await fetch('medicos_api.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: buildMedBody(page)
    });
    const text = await res.text();
    let js;
    try { js = JSON.parse(text); } catch(e){ elMed.resultado.innerHTML = '<div class="alert alert-danger">Respuesta inválida del servidor. Mirá DevTools → Network.</div>'; console.error('medicos_api raw:', text); return; }
    if (!js.success) { elMed.resultado.innerHTML = '<div class="alert alert-danger">Error: '+(js.error||'Error servidor')+'</div>'; return; }
    renderMedTable(js);
  }catch(e){
    elMed.resultado.innerHTML = '<div class="alert alert-danger">Error al cargar: '+e.message+'</div>';
  }
}

function renderMedTable(payload){
  const rows = payload.data || [];
  const total = payload.total || 0;
  const page = payload.page || 1;
  const per = payload.per_page || 20;
  const total_pages = payload.total_pages || 1;

  let html = '<table class="table table-striped"><thead><tr><th>ID</th><th>Nombre</th><th>Especialidad</th><th>Acciones</th></tr></thead><tbody>';
  if (rows.length === 0) {
    html += '<tr><td colspan="4" class="text-center">No se encontraron médicos.</td></tr>';
  } else {
    for (const r of rows) {
      const id = r.id_medico;
      const nombre = escapeHtml((r.nombre || '') + ' ' + (r.apellido || ''));
      const esp = escapeHtml(r.especialidad || '');
      html += `<tr>
        <td class="nowrap">${id}</td>
        <td>${nombre}</td>
        <td>${esp}</td>
        <td class="nowrap">
          <a href="medicos_form.php?id=${id}" class="btn btn-sm btn-primary js-go-form">Editar</a>
          <a href="medicos_borrar.php?id=${id}" class="btn btn-sm btn-danger" onclick="return confirm('¿Borrar médico?')">Borrar</a>
        </td>
      </tr>`;
    }
  }
  html += '</tbody></table>';

  // pagination
  html += '<div class="d-flex justify-content-between align-items-center">';
  html += `<div>Mostrando ${rows.length} de ${total} resultados</div>`;

  const maxButtons = 7;
  let start = Math.max(1, page - Math.floor(maxButtons/2));
  let end = start + maxButtons - 1;
  if (end > total_pages) { end = total_pages; start = Math.max(1, end - maxButtons + 1); }

  html += '<nav aria-label="Paginación"><ul class="pagination mb-0">';
  html += page > 1 ? `<li class="page-item"><a class="page-link" href="#" data-page="${page-1}">«</a></li>` : `<li class="page-item disabled"><span class="page-link">«</span></li>`;

  if (start > 1) { html += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`; if (start > 2) html += `<li class="page-item disabled"><span class="page-link">…</span></li>`; }
  for (let p=start; p<=end; p++){ html += `<li class="page-item${p===page?' active':''}"><a class="page-link" href="#" data-page="${p}">${p}</a></li>`; }
  if (end < total_pages) { if (end < total_pages-1) html += `<li class="page-item disabled"><span class="page-link">…</span></li>`; html += `<li class="page-item"><a class="page-link" href="#" data-page="${total_pages}">${total_pages}</a></li>`; }
  html += page < total_pages ? `<li class="page-item"><a class="page-link" href="#" data-page="${page+1}">»</a></li>` : `<li class="page-item disabled"><span class="page-link">»</span></li>`;
  html += '</ul></nav></div>';

  elMed.resultado.innerHTML = html;

  // pagination handlers
  document.querySelectorAll('#resultadoMed .page-link[data-page]').forEach(a=>{
    a.addEventListener('click', (e)=>{ e.preventDefault(); fetchMed(parseInt(a.dataset.page)||1); });
  });

  // attach form links to replace history
  document.querySelectorAll('.js-go-form').forEach(a=>{
    if (a.dataset.attached === '1') return;
    a.dataset.attached = '1';
    a.addEventListener('click', function(ev){ ev.preventDefault(); location.replace(this.getAttribute('href')); });
  });
}

const debMed = debounce(()=> fetchMed(1), 300);
elMed.q.addEventListener('input', debMed);
elMed.esp.addEventListener('change', ()=> fetchMed(1));
elMed.sort.addEventListener('change', ()=> fetchMed(1));
elMed.per.addEventListener('change', ()=> fetchMed(1));
elMed.clear.addEventListener('click', ()=> { elMed.q.value=''; elMed.esp.value=''; elMed.sort.value='nombre_asc'; elMed.per.value='20'; fetchMed(1); });

// ensure top New link replaces history
if (elMed.linkNuevo) elMed.linkNuevo.addEventListener('click', function(e){ e.preventDefault(); location.replace(this.getAttribute('href')); });

// initial
fetchMed(1);
</script>
</body>
</html>
