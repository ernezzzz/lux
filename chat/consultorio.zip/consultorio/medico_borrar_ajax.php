<?php
// consultorio/medico_borrar_ajax.php
header('Content-Type: application/json; charset=utf-8');
include '../../backend/checklogin.php';
include '../../backend/conexion.php';

try {
  $id_medico = isset($_POST['id_medico']) ? intval($_POST['id_medico']) : 0;
  if (!$id_medico) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'ID de médico inválido.']);
    exit;
  }

  // comprobar existencia y activo
  $stmt = mysqli_prepare($conn, "SELECT id_medico, activo FROM medicos WHERE id_medico = ? LIMIT 1");
  mysqli_stmt_bind_param($stmt, 'i', $id_medico);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_store_result($stmt);
  if (mysqli_stmt_num_rows($stmt) === 0) {
    mysqli_stmt_close($stmt);
    http_response_code(404);
    echo json_encode(['success'=>false,'error'=>'Médico no encontrado.']);
    exit;
  }
  mysqli_stmt_bind_result($stmt, $mid, $mactivo);
  mysqli_stmt_fetch($stmt);
  mysqli_stmt_close($stmt);

  if ($mactivo == 0) {
    // idempotente: ya inactivo
    echo json_encode(['success'=>true,'info'=>'Médico ya inactivo.']);
    exit;
  }

  // contar turnos PENDIENTE/CONFIRMADO activos asociados al medico
  $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM turnos WHERE id_medico = ? AND activo = 1 AND estado IN ('pendiente','confirmado')");
  mysqli_stmt_bind_param($stmt, 'i', $id_medico);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_bind_result($stmt, $cntPendConf);
  mysqli_stmt_fetch($stmt);
  mysqli_stmt_close($stmt);

  if ($cntPendConf > 0) {
    http_response_code(409);
    echo json_encode(['success'=>false,'error'=>'No se puede borrar el médico porque tiene registros relacionados.']);
    exit;
  }

  // proceder a soft-delete: marcar turnos finalizados/cancelados como inactivos y marcar médico inactivo
  mysqli_begin_transaction($conn);
  $now = date('Y-m-d H:i:s');

  // 1) soft-delete de turnos finalizado/cancelado
  $stmt = mysqli_prepare($conn, "UPDATE turnos SET activo = 0, deleted_at = ? WHERE id_medico = ? AND activo = 1 AND estado IN ('finalizado','cancelado')");
  mysqli_stmt_bind_param($stmt, 'si', $now, $id_medico);
  $ok = mysqli_stmt_execute($stmt);
  if ($ok === false) {
    $err = mysqli_error($conn);
    mysqli_stmt_close($stmt);
    mysqli_rollback($conn);
    throw new Exception('Error al marcar turnos: ' . $err);
  }
  $affected_turnos = mysqli_stmt_affected_rows($stmt);
  mysqli_stmt_close($stmt);

  // 2) soft-delete del medico
  $stmt = mysqli_prepare($conn, "UPDATE medicos SET activo = 0, deleted_at = ? WHERE id_medico = ?");
  mysqli_stmt_bind_param($stmt, 'si', $now, $id_medico);
  $ok = mysqli_stmt_execute($stmt);
  if ($ok === false) {
    $err = mysqli_error($conn);
    mysqli_stmt_close($stmt);
    mysqli_rollback($conn);
    throw new Exception('Error al marcar médico: ' . $err);
  }
  $affected_med = mysqli_stmt_affected_rows($stmt);
  mysqli_stmt_close($stmt);

  mysqli_commit($conn);

  echo json_encode([
    'success'=>true,
    'id_medico'=>$id_medico,
    'turnos_soft_deleted'=>(int)$affected_turnos,
    'medico_soft_deleted'=>(int)$affected_med
  ], JSON_UNESCAPED_UNICODE);
  exit;

} catch (Exception $ex) {
  if (isset($conn)) @mysqli_rollback($conn);
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$ex->getMessage()]);
  exit;
}
