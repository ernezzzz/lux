<?php
// consultorio/turnos_api.php  (POST, JSON)
header('Content-Type: application/json; charset=utf-8');
include '../../backend/checklogin.php';
include '../../backend/conexion.php';

try {
  $q = isset($_POST['q']) ? trim($_POST['q']) : '';
  $estado = isset($_POST['estado']) ? trim($_POST['estado']) : '';
  $medico = isset($_POST['medico']) ? intval($_POST['medico']) : 0;
  $sort = isset($_POST['sort']) ? $_POST['sort'] : 'fecha_desc';
  $per_page = max(1, intval($_POST['per_page'] ?? 15)); // default 15
  $page = max(1, intval($_POST['page'] ?? 1));
  $offset = ($page - 1) * $per_page;

  $where = [];
  // only active turnos
  $where[] = "t.activo = 1";

  if ($q !== '') {
    $esc = mysqli_real_escape_string($conn, $q);
    $where[] = "(CONCAT_WS(' ', u.nombre, u.apellido) LIKE '%$esc%' OR CONCAT_WS(' ', m.nombre, m.apellido) LIKE '%$esc%' OR COALESCE(u.email,'') LIKE '%$esc%')";
  }
  if ($estado !== '') {
    $e = mysqli_real_escape_string($conn, $estado);
    $where[] = "t.estado = '$e'";
  }
  if ($medico) {
    $mid = (int)$medico;
    $where[] = "t.id_medico = $mid";
  }
  $where_sql = $where ? 'WHERE '.implode(' AND ', $where) : '';

  $order_sql = "ORDER BY t.fecha DESC, t.hora DESC";
  if ($sort === 'fecha_asc') $order_sql = "ORDER BY t.fecha ASC, t.hora ASC";
  if ($sort === 'paciente_asc') $order_sql = "ORDER BY paciente_nombre ASC";
  if ($sort === 'paciente_desc') $order_sql = "ORDER BY paciente_nombre DESC";

  $count_sql = "SELECT COUNT(*) AS total
    FROM turnos t
    LEFT JOIN usuarios u ON t.id_paciente = u.id_usuario
    LEFT JOIN medicos m ON t.id_medico = m.id_medico
    $where_sql";
  $count_res = mysqli_query($conn, $count_sql);
  if (!$count_res) throw new Exception('Error count: '.mysqli_error($conn));
  $row = mysqli_fetch_assoc($count_res);
  $total = (int)$row['total'];

  $sql = "SELECT t.id_turno, t.id_paciente, t.fecha, t.hora, t.estado,
                 COALESCE(CONCAT_WS(' ', u.nombre, u.apellido),'') AS paciente_nombre,
                 COALESCE(CONCAT_WS(' ', m.nombre, m.apellido),'') AS medico_nombre,
                 COALESCE(u.email,'') AS paciente_email
          FROM turnos t
          LEFT JOIN usuarios u ON t.id_paciente = u.id_usuario
          LEFT JOIN medicos m ON t.id_medico = m.id_medico
          $where_sql
          $order_sql
          LIMIT $per_page OFFSET $offset";
  $res = mysqli_query($conn, $sql);
  if ($res === false) throw new Exception('Error select: '.mysqli_error($conn));

  $data = [];
  while ($r = mysqli_fetch_assoc($res)) {
    $data[] = [
      'id_turno' => (int)$r['id_turno'],
      'id_paciente'=> (int)$r['id_paciente'],
      'fecha' => $r['fecha'],
      'hora' => $r['hora'] ? date('H:i', strtotime($r['hora'])) : '',
      'estado' => $r['estado'],
      'paciente_nombre' => $r['paciente_nombre'],
      'paciente_email' => $r['paciente_email'],
      'medico_nombre' => $r['medico_nombre'],
    ];
  }

  $total_pages = $total > 0 ? (int)ceil($total / $per_page) : 1;

  echo json_encode([
    'success' => true,
    'total' => $total,
    'per_page' => $per_page,
    'page' => $page,
    'total_pages' => $total_pages,
    'data' => $data,
  ], JSON_UNESCAPED_UNICODE);
  exit;
} catch (Exception $ex) {
  http_response_code(500);
  echo json_encode(['success'=>false, 'error' => $ex->getMessage()]);
  exit;
}


