<?php
include '../../backend/checklogin.php';
include '../../backend/header.php';
include '../../backend/conexion.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id) { header('Location: turnos_listar.php'); exit; }

mysqli_query($conn, "DELETE FROM turnos WHERE id_turno=$id") or die('Error delete: '.mysqli_error($conn));
header('Location: turnos_listar.php');
exit;
